
#include <dos.h>
#include <stdio.h>

#include <general.h>

#include <unos.h>
#include <kbtask.h>		/* contains prototype for return_os_termination*/
#include <main_ext.h>	/* contains prototype for get_fileptr	*/

#include <hwpc.h>
#include <pcscr.h>
#include <serial.h>		/* prototypes for restore_serial_driver */

extern void restore_keyboard ( void );

void null_task ( void * Dummy ) {

	int temp = 1;

	start_time_slice ( );
	enable ( );
	Dummy = Dummy;

	while ( temp )	{

		temp = return_os_termination ( );

		} /* while */

	/*---- Put DOS clock Back */
	stop_time_slice ( );

	/*---- Clean up interrupt drivers */
	restore_dos_mode ( );

	/*---- Wipe the screen and return a cursor */
	/* Note that graphics should be removed and normal mode restored. */
	restore_pc_screen ( );

	enable ( );

} /* end of null_task */


