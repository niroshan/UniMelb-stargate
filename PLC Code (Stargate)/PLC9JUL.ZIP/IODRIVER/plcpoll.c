/*
********************************************************************************
PLCpoll.C

Task to communicate to the PLC from external PC

Author:	Len Sciacca
Date:	1994/1998

plcpoll_message expects a poll in form,
STX        - 1 byte
POLL       - 1 byte   Set Poll=1 for one transmission every 300ms
DAC AZ     - 2 bytes
DAC EL     - 2 bytes
Drive word - 1 byte    //see plc.c
Checksum   - 1 bytes

Total: 9bytes
If there is a timeout ( 1 sec) then a error is flagged.
This routine is called from the plcpoll task
If there is a proper poll, then send back the current data

STX        - 1 byte
AZ Encoder - 2 bytes
EL Encoder - 2 bytes
ADC        - 2 bytes
plc word 1 - 1 byte  (see plc.c)
plc word 2 - 1 byte  (see plc.c)
plc word 3 - 1 byte  (see plc.c)
checksum   - 2 bytes

Total: 12 bytes
********************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>

#include "general.h"
#include "taskname.h"   // ch_1_tx

#include "unos.h"

#include <unosdef.h>
#include "plc.h"
#include "plcext.h"   // extern ReadPLCWords(), plc_timer1 ( int * temp );

#define NUL 0x00
#define SOH	0x01
#define STX	0x02
#define ETX 0x03
#define EOT	0x04
#define ENQ	0x05
#define ACK	0x06
#define BEL 0x07
#define BS  0x08
#define HT  0x09
#define LF  0x0A
#define VT  0x0B
#define FF  0x0C
#define CR  0x0D
#define SO  0x0E
#define SI  0x0F
static char plcpoll_message( char *message, int time_out );
static char plcpoll_messageTest( char *message, int time_out );
static unsigned char rx_mess [ 30 ];
static unsigned int rx_mess_length;

static char word1, word2, word3;
	// PLC structure contains the actual fault/conditions
	// PLC-bit contains the bit image of the PLC words
static PLC_struct PLC;
static PLC_struct PLC_bit;
static unsigned int task_count= 0;
static unsigned int count=0;
static unsigned int checksum_count=0;

static char string [ 20 ];
unsigned char display_temp[20];
/*
****************************************************************************
plcpoll_task ( )

****************************************************************************
*/
void plcpoll_task ( void * Dummy ) {

	int temp, i;
	unsigned int return_status;
	unsigned char status;
	char ch1, ch2;
	char sendbuf [40];
	unsigned char adc[2], azencoder[2], elencoder[2], dacaz[2], dacel[2];
	unsigned char word1, word2, word3, PLCPoll;
	unsigned char checksum, driveword;

	enable ( );
	Dummy = Dummy;


	// Attach to serial channel 0
	//This initialises the rx task with who it needs to send
	// it's data to
	send_mess( (unsigned char *)"?",1, ch_0_rx );

	while ( 1 ) {
		// Clear important words
		dacaz[0]=0;
		dacaz[1]=0;
		dacel[0]=0;
		dacel[1]=0;
		PLCPoll=0;

		// Wait for Poll from external comms
		// if timeout...send a character down the line, just to tell
		// someone we are alive!
		status = plcpoll_message( rx_mess, 60 );

		// Do a simple test by checking for a character from a terminal
		// and replying with the required data!

		// returns a NULL if timeout
		// Only process if ACK is returned and not time-out
		if ( ( status != NULL ) && ( rx_mess [0] == STX ) )
			{
			checksum=0;
			for (i=0; i < 7; i++ )
				{
				checksum += (unsigned char)rx_mess[ i ];
				}
			// check checksum
			if (checksum==rx_mess[7])
			  {
			  // Now strip off the data from the PLC reply
			  PLCPoll =rx_mess[1];
			  dacaz[0]=rx_mess[2];
			  dacaz[1]=rx_mess[3];
			  dacel[0]=rx_mess[4];
			  dacel[1]=rx_mess[5];
			  // 1. Unpack PLC Command in "drive_word"
			  driveword=rx_mess[6];
			  }
			else
			{
			// error
			}


			} // if
		else
			{
			flush_mbx ( );		// clear mailbox and start afresh
			//send_mess( (unsigned char *)"?",1, ch_0_tx );      // send message to
																				// anyone
			} // else

		// Read Encoders
		azencoder[0]='D';
		azencoder[1]='S';
		elencoder[0]='T';
		elencoder[1]='O';
		// Read ADC
		adc[0]=':';
		adc[1]=')';

      // write to DACs

		// Read PLC
		// Returns the bytes, word1, word2 word3 which the user must decipher
		ReadPLCWords (&word1, &word2, &word3);

		// Pack the reply and send
		sendbuf[0]=STX;
		sendbuf[1]=azencoder[0];
		sendbuf[2]=azencoder[1];
		sendbuf[3]=elencoder[0];
		sendbuf[4]=elencoder[1];
		sendbuf[5]=adc[0];
		sendbuf[6]=adc[1];
		sendbuf[7]=word1;
		sendbuf[8]=word2;
		sendbuf[9]=word3;
		sendbuf[10]=NULL;

		// Make checksum
		checksum = 0;
		for( i = 1; i < (strlen(sendbuf)); i++ )
		  {
		  checksum += (unsigned char)sendbuf[ i ];
		  }
		sendbuf[10]=checksum;
		sendbuf[11]=NULL;

		if ( free_mbx ( ch_0_tx ) > 1 )
		  send_mess( (unsigned char *)sendbuf, strlen( sendbuf ), ch_0_tx );
		  //send_mess( "Data...", strlen( "Data..." ), ch_0_tx );

		// Write PLC data, PLC task will send it off when it is ready.
		if (PLCPoll==1)
		  {
		  WritePLC (driveword);
		  plc_timer1 ( ); // wake up PLC communication task
		  }

	} /* end of infinite while loop */

} /* End of plcpoll_task */


/************************************************************************
* plcpoll_message
* This routine is designed to receive data from a Rx serial handler task,
* and collects the string until a LF is received or an error has occured.
* It then performs checking/stripping as per the Mitsubishi protocol.
* An error code is returned if required. The string will be returned via
* the calling parameter string.
* (N.B. Re-entrant routine.)
*
*************************************************************************/

static char plcpoll_message( char *message, int time_out )
{
	unsigned int error = 0, readchecksum = 0;
	unsigned char checksum = 0, temp;
	char buf[ 30 ];
	int enddata, i, message_index = 0;
	char EndMessage;
	char * status;

	rx_mess[0]='\0';

	message_index = 0;
	EndMessage = 0;

	i=1;

	count++;
	checksum_count = 0;

	do
	{
		/* Wait for bytes to arrive from the serial handler. */
		status = rcv_mess( &rx_mess[0], &rx_mess_length, time_out );

		// check for timeout
		if (status == NULL)
		  {
		  display_temp[0]='X';
		  display_temp[1]=NULL;
		  rx_mess[0]=NULL;
		  EndMessage=1;
		  message_index=1;
		  error=1;
		  }

		if ( rx_mess[0] == STX )  // hope first is STX
			{
			if (message_index>0)
				EndMessage = 1;
			else {
			  message_index = 0;
			  i=1;
			  message [ message_index ] = rx_mess[0];
			  checksum_count = 1;
			  message_index++;
			  }
			}
		else if ( message_index > 0 )
			{
			message[ message_index ] = rx_mess[0];
			message_index++;
			checksum_count++;

			if ((checksum_count == 9))
				{
				EndMessage = 1;
				message[message_index]=NULL;
				message_index = 0;
				}
			}

		i++;

	} while ( !EndMessage );	 // DO


	if ( error )
		return NULL;

	/* The message passed to this function should start with an STX*/
	enddata = strlen( message );      /* N.B. Length does not include NULL. */


	switch ( message[ 0 ] )
	{
		case NULL:
					return (NULL);  // timeout

		case STX:
					/* Calculate the checksum */
					checksum = 0;
					for( i = 1; i < (enddata-2); i++ )
						{
						checksum += (unsigned char)message[ i ];
						}

					/* Now read the checksum and compare */
					strcpy( buf, &message[ enddata-2 ] );
					strcpy( display_temp, &message[ enddata-2 ]);

					if ( (sscanf( buf, "%x", &readchecksum ) == 1) &&
							((((unsigned int)checksum)&0xff) == readchecksum) )
						{
						/* Remove the checksum and the ETX */
						message[ enddata-3 ] = NULL;
						display_temp[ enddata-3 ] = NULL;

						/* Now shift the data area */
						enddata = strlen(message);
						for( i = 1; i <= enddata; i++ )
							message[i-1] = message[i];

						return 0;
						}
					else
						{
						/* We have a problem, return the error */
						/* Either the scan failed, or the checksum != */
						return (-1);
						}

		default  : return (-1);
	} // switch

}

/************************************************************************
* plcpoll_messageTest
* Used ONLY to test communications between COM1 and the Poll task
* This routine is designed to receive data from a Rx serial handler task,
* and collects the string until a LF is received or an error has occured.
* It then performs checking/stripping as per the Mitsubishi protocol.
* An error code is returned if required. The string will be returned via
* the calling parameter string.
* (N.B. Re-entrant routine.)
*
*************************************************************************/

static char plcpoll_messageTest( char *message, int time_out )
{
	unsigned int error = 0, readchecksum = 0;
	unsigned char checksum = 0, temp;
	char buf[ 30 ];
	int enddata, i, message_index = 0;
	char EndMessage;
	char * status;

	rx_mess[0]='\0';

	message_index = 0;
	EndMessage = 0;

	i=1;

	count++;
	checksum_count = 0;

	do
	{
		/* Wait for bytes to arrive from the serial handler. */
		status = rcv_mess( &rx_mess[0], &rx_mess_length, time_out );

		// Testing only July 1998
		if (status != NULL)
		  {
		  temp=rx_mess[0];
		  rx_mess[0]=STX;
		  rx_mess[1]='g';
		  rx_mess[2]=temp;
		  rx_mess[3]='a';
		  rx_mess[4]='b';
		  rx_mess[5]='c';
		  rx_mess[6]=0x0;
		  rx_mess[7]=NULL;

		  // Make checksum
		  checksum = 0;
		  for( i = 1; i < (strlen(rx_mess)); i++ )
			 {
			 checksum += (unsigned char)rx_mess[ i ];
			 message[i-1]= (unsigned char)rx_mess[ i-1 ];
			 display_temp[i-1]=rx_mess[i];
			 }
		  rx_mess[7]=checksum;
		  rx_mess[8]=NULL;
        message[8]=NULL;
		  EndMessage=1;
        display_temp[7]=NULL;
		 }

		// check for timeout
		else //if (status == NULL)
		  {
		  display_temp[0]='X';
		  display_temp[1]=NULL;
		  rx_mess[0]=NULL;
		  EndMessage=1;
		  message_index=1;
		  error=1;
		  }
 /*
		if ( rx_mess[0] == STX )  // hope first is STX
			{
			if (message_index>0)
				EndMessage = 1;
			else {
			  message_index = 0;
			  i=1;
			  message [ message_index ] = rx_mess[0];
			  checksum_count = 1;
			  message_index++;
			  }
			}
		else if ( message_index > 0 )
			{
			message[ message_index ] = rx_mess[0];
			message_index++;
			checksum_count++;

			if ((checksum_count == 9))
				{
				EndMessage = 1;
				message[message_index]=NULL;
				message_index = 0;
				}
			}
  */
		i++;

	} while ( !EndMessage );	 // DO


	if ( error )
		return NULL;

	/* The message passed to this function should start with an STX*/
	enddata = strlen( message );      /* N.B. Length does not include NULL. */


	switch ( message[ 0 ] )
	{
		case NULL:
					return (NULL);  // timeout

		case STX:
					/* Calculate the checksum */
					checksum = 0;
					for( i = 1; i < (enddata-2); i++ )
						{
						checksum += (unsigned char)message[ i ];
						}

					/* Now read the checksum and compare */
					strcpy( buf , &message[ enddata-2 ] );

					if ( (sscanf( buf, "%x", &readchecksum ) == 1) &&
							((((unsigned int)checksum)&0xff) == readchecksum) )
						{
						/* Remove the checksum and the ETX */
						message[ enddata-3 ] = NULL;

						/* Now shift the data area */
						enddata = strlen(message);
						for( i = 1; i <= enddata; i++ )
							message[i-1] = message[i];

						return 0;
						}
					else
						{
						/* We have a problem, return the error */
						/* Either the scan failed, or the checksum != */
						return (-1);
						}

		default  : return (-1);
	} // switch

}

